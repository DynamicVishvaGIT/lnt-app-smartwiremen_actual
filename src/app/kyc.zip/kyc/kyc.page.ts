// import { Component, OnInit } from '@angular/core';
import { Component, OnInit, ViewChild } from '@angular/core';
import {  ToastController, LoadingController, MenuController } from '@ionic/angular';
import { TranslateService } from '@ngx-translate/core';
import { IonicSelectableComponent } from 'ionic-selectable';

import { Camera, CameraOptions } from '@ionic-native/camera/ngx';
import { FileTransfer} from '@ionic-native/file-transfer/ngx';
import { File, FileEntry } from '@ionic-native/file/ngx';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { ChangeDetectorRef } from '@angular/core'; 
import { ApiService } from '../providers/api-service/api.service';
import { TokenService } from '../providers/token-service/token.service';
import { EventsService } from '../providers/events-service/events.service';
import { DatePicker } from '@ionic-native/date-picker/ngx';

@Component({
  selector: 'app-kyc',
  templateUrl: './kyc.page.html',
  styleUrls: ['./kyc.page.scss'],
})
export class KycPage implements OnInit {
  disabled = true;
  showKycForm = false;
  showKycFormdistwo = true;
  showKycFormdisone = true;
  tc = null;
  profile_pic:any;
  pan_card_img:any;
  base64pancardImage:any;
  pancardBlob: Blob;
  
  aadhar_card_img:any;
  base64aadharcardImage:any;
  aadharcardBlob: Blob;
  
  cancel_cheque_img:any;
  base64cancelchequeImage:any;
  cancelchequeBlob: Blob;

  accessToken:any;
  kycFormField = {
		linked_phonenumber: null,
    pan_card_no: null,
    aadhar_no: null,
    cancel_check_no: null,
    terms_condition:null,
    terms_conditions:null,
    pan_card_img: null,
    aadhar_card_img: null,
    cancel_cheque_img:null,
  };
  tran_please_wait:string = "Please Wait";
  tran_required_linked_phonenumber:string = "Enter Pan & Aadhar link Phone Number";
  tran_required_pan_card_no:string = "Enter Pan Card Number";
  tran_required_aadhar_no:string = "Enter Aadhar Card Number";
  tran_required_cancel_check_no:string = "Enter Cancel Cheque Number";
  tran_kyc_updated:string = "KYC Updated Successfully";

  tran_went_wrong:string = 'Something went wrong, please try again later.';
  

  constructor(
    private toastCtrl: ToastController,
    public loadingCtrl: LoadingController,
    private apiService: ApiService,
    public events: EventsService,
    public token: TokenService,
    public translate: TranslateService,
    public menuCtrl: MenuController,
    private camera: Camera,
    private transfer: FileTransfer,
    private file: File,
    public formBuilder: FormBuilder,
    public cf : ChangeDetectorRef,
    private datePicker: DatePicker,
    public router:Router
  ) {
    this.events.getEvent().subscribe((data) => {
      console.log('data',data)
      if(data){
      if(data.name=='update:kycdata'){
        

        this.kycFormField.linked_phonenumber = data.params.linked_phonenumber;
        this.kycFormField.pan_card_no = data.params.pan_card_no;
        this.kycFormField.aadhar_no = data.params.aadhar_no;
        this.kycFormField.cancel_check_no = data.params.cancel_check_no;
        this.kycFormField.terms_condition = data.params.terms_condition;
        this.kycFormField.terms_conditions = data.params.terms_conditions;

        this.kycFormField.pan_card_img = data.params.pan_card_img;
        this.kycFormField.aadhar_card_img = data.params.aadhar_card_img;
        this.kycFormField.cancel_cheque_img = data.params.cancel_cheque_img;

        
      }
    }
    });
    
    

  }

  showKyc(){    
      this.showKycForm = true;
      this.showKycFormdisone = true;
      this.showKycFormdistwo = true;

      if(this.kycFormField.aadhar_no == '' || this.kycFormField.aadhar_no == null){
        this.presentToast(this.tran_required_aadhar_no);
        this.showKycForm = false;
        this.showKycFormdisone = true;
        this.showKycFormdistwo = true;
      }else{
        if(this.kycFormField.pan_card_no == '' || this.kycFormField.pan_card_no == null){
          this.showKycFormdistwo = false;
          this.showKycForm = true;
          this.showKycFormdisone = true;
        }else{
          this.showKycForm = true;
          this.showKycFormdisone = false;
          this.showKycFormdistwo = true;
        }
      }
    
    
  }
  checkKyc(){
    this.disabled = false;
    // console.log(this.kycFormField.terms_condition)
    if(this.kycFormField.terms_condition == true){
      // console.log(this.kycFormField.terms_condition)
      this.disabled = false;
      this.tc = "10"
      // console.log(this.kycFormField.terms_condition)
    }else{
      this.disabled = true;
    }
  }
  checkKyctwo(){
    this.disabled = false;
    // console.log(this.kycFormField.terms_condition)
    if(this.kycFormField.terms_conditions == true){
      // console.log(this.kycFormField.terms_condition)
      this.disabled = false;
      this.tc = "20"
      // console.log(this.kycFormField.terms_conditions)
    }else{
      this.disabled = true;
    }
  }
  kycForm(){

    if(this.kycFormField.aadhar_no == '' || this.kycFormField.aadhar_no == null){
      this.presentToast(this.tran_required_aadhar_no);
    }else{

      this.presentLoading()
      
        
        var kycFormField = {
          'linked_phonenumber': this.kycFormField.linked_phonenumber,
          'pan_card_no': this.kycFormField.pan_card_no,
          'aadhar_no': this.kycFormField.aadhar_no,
          'cancel_check_no':this.kycFormField.cancel_check_no,
          'terms_condition':this.tc,
          
          'oldpan_card_img':this.pan_card_img,
          'pan_card_img':this.pan_card_img,
          'base64pancardImage':this.base64pancardImage,

          'oldaadhar_card_img':this.aadhar_card_img,
          'aadhar_card_img':this.aadhar_card_img,
          'base64aadharcardImage':this.base64aadharcardImage,

          'oldcancel_cheque_img':this.cancel_cheque_img,
          'cancel_cheque_img':this.cancel_cheque_img,
          'base64cancelchequeImage':this.base64cancelchequeImage,
        };
      console.log('add',kycFormField)
        this.apiService.uploadKyc(kycFormField).subscribe(
          data => {
            this.loadingCtrl.dismiss();
            if(data){
              this.presentToast(this.tran_kyc_updated);
              // this.router.navigate(['disclaimer'])
            }else{
              this.presentToast(this.tran_went_wrong);
            }
            
          },
          error => this.handleError(error)
        );
    }
  }

  handleResponse(data) {
    this.loadingCtrl.dismiss()
      this.events.publish({name:'update:kycdata',params:data});
      console.log()
	    this.events.publish({name:'update:userdata',params:data});
	}

	handleError(error) {
    this.loadingCtrl.dismiss()
    
		let errorMsg = '';
		if(error.status == 401){
		  errorMsg = error.error.message;
		}else{
      errorMsg = error.error.error;
    }
		
		if(errorMsg != ''){
		  this.presentToast(errorMsg);
		}
	}

  
  // takePhoto(){
  //   const options: CameraOptions = {
  //     quality: 70,
  //     destinationType: this.camera.DestinationType.FILE_URI,
  //     encodingType: this.camera.EncodingType.JPEG,
  //     mediaType: this.camera.MediaType.PICTURE,
  //     correctOrientation: true
     
  //   }

  //   this.camera.getPicture(options).then((imageData) => {
  //   //  this.profile_pic = 'data:image/jpeg;base64,' + imageData;
  //    this.file.resolveLocalFilesystemUrl(imageData).then((entry: FileEntry) => {
  //     entry.file(file => {
  //       console.log(file);
  //       this.file_name=file.name
  //       this.base64Image = (<any>window).Ionic.WebView.convertFileSrc(imageData);
  //       this.cf.detectChanges();
  //       this.readFile(file);
  //     });
  //   });
  //   }, (err) => {
  //    this.base64Image = null;      
  //   });
  // }

  async presentToast(message) {
    const toast = await this.toastCtrl.create({
      message: message,
      duration: 3000,
      position:'middle'
    });
    toast.present();
  }
  async presentLoading() {
    const loading = await this.loadingCtrl.create({
      spinner: 'crescent',
      message: this.tran_please_wait+'...',
    });
    await loading.present();

    const { role, data } = await loading.onDidDismiss();
    console.log('Loading dismissed!');
  }

  getpancardImage(){
    const options: CameraOptions = {
      quality: 70,
      destinationType: this.camera.DestinationType.FILE_URI,
      encodingType: this.camera.EncodingType.JPEG,
      mediaType: this.camera.MediaType.PICTURE,
      correctOrientation: true,
      sourceType: this.camera.PictureSourceType.PHOTOLIBRARY
    }

    this.camera.getPicture(options).then((imageData) => {
      this.file.resolveLocalFilesystemUrl(imageData).then((entry: FileEntry) => {
        entry.file(file => {
          console.log(file);
          this.pan_card_img=file.name
          this.base64pancardImage = (<any>window).Ionic.WebView.convertFileSrc(imageData);
          this.cf.detectChanges();
          this.pancardreadFile(file);
        });
      });
    //  this.profile_pic = 'data:image/jpeg;base64,' + imageData;
    }, (err) => {
      this.base64pancardImage = null;
    });
  }
  pancardreadFile(file: any) {
    const reader = new FileReader();
    reader.onloadend = () => {
      this.pancardBlob = new Blob([reader.result], {
        type: file.type
      });
     console.log("name",file.name)
     
     
    };
    reader.readAsArrayBuffer(file);
  }
  getaadharcardImage(){
    const options: CameraOptions = {
      quality: 70,
      destinationType: this.camera.DestinationType.FILE_URI,
      encodingType: this.camera.EncodingType.JPEG,
      mediaType: this.camera.MediaType.PICTURE,
      correctOrientation: true,
      sourceType: this.camera.PictureSourceType.PHOTOLIBRARY
    }

    this.camera.getPicture(options).then((imageData) => {
      this.file.resolveLocalFilesystemUrl(imageData).then((entry: FileEntry) => {
        entry.file(file => {
          console.log(file);
          this.aadhar_card_img=file.name
          this.base64aadharcardImage = (<any>window).Ionic.WebView.convertFileSrc(imageData);
          this.cf.detectChanges();
          this.aadharcardreadFile(file);
        });
      });
    //  this.profile_pic = 'data:image/jpeg;base64,' + imageData;
    }, (err) => {
      this.base64aadharcardImage = null;
    });
  }
  aadharcardreadFile(file: any) {
    const reader = new FileReader();
    reader.onloadend = () => {
      this.aadharcardBlob = new Blob([reader.result], {
        type: file.type
      });
     console.log("name",file.name)
    };
    reader.readAsArrayBuffer(file);
  }
  getcancelchequeImage(){
    const options: CameraOptions = {
      quality: 70,
      destinationType: this.camera.DestinationType.FILE_URI,
      encodingType: this.camera.EncodingType.JPEG,
      mediaType: this.camera.MediaType.PICTURE,
      correctOrientation: true,
      sourceType: this.camera.PictureSourceType.PHOTOLIBRARY
    }

    this.camera.getPicture(options).then((imageData) => {
      this.file.resolveLocalFilesystemUrl(imageData).then((entry: FileEntry) => {
        entry.file(file => {
          console.log(file);
          this.cancel_cheque_img=file.name
          this.base64cancelchequeImage = (<any>window).Ionic.WebView.convertFileSrc(imageData);
          this.cf.detectChanges();
          this.cancelchequereadFile(file);
        });
      });
    //  this.profile_pic = 'data:image/jpeg;base64,' + imageData;
    }, (err) => {
      this.base64cancelchequeImage = null;
    });
  }
  cancelchequereadFile(file: any) {
    const reader = new FileReader();
    reader.onloadend = () => {
      this.cancelchequeBlob = new Blob([reader.result], {
        type: file.type
      });
     console.log("name",file.name)
    };
    reader.readAsArrayBuffer(file);
  }
  

  



  goBack(){
    this.router.navigate(['profile'])
  }
  ngOnInit() {
    // this.showKycFormdistwo = false;
    // this.showKycFormdisone = false;
    
  }
}
